# PHP-livredor

## Fait avec XAMP.

Pensez à faire tourner (sous XAMPP) Apache ET MySQL ! Et glissez le projet livredor/ dans <strong>htdocs</strong>. (de même sous MAMP)<br>
(Sur WAMP --> dossier www/)

Votre XAMPP devrait ressembler à cela.
![MySQL et Apache running.](https://cdn.discordapp.com/attachments/676022977082687540/1316668589755076608/image.png?ex=675be2ae&is=675a912e&hm=6da63b9eb8fd195aa336da70986bdae674daa6d4eb162281411ba2837f885b68&)

<strong>Lien localhost :</strong> http://localhost/livredor